from dataclasses import dataclass

@dataclass
class CartItem:
    item_id: str
    price: float
    quantity: int = 1
