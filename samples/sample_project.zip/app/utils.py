def calculate_discount(amount: float, coupon: str | None = None) -> float:
    if coupon == 'DISCOUNT10':
        return amount * 0.10
    if coupon == 'DISCOUNT20':
        return amount * 0.20
    return 0.0

def format_currency(val: float) -> str:
    return f''
