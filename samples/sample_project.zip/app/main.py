import os
from app.utils import calculate_discount, format_currency

def checkout(cart_items, coupon=None, user_discounts=[]):
    total = sum(item['price'] for item in cart_items)
    discount = calculate_discount(total, coupon)
    final_total = max(0.0, total - discount)
    user_discounts.append(discount)
    return format_currency(final_total)
